
import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';
// import {namehash} from 'eth-ens-namehash';
import PublicResolverABI from './PublicResolverABI.json';
import './App.css';
import ensRegistry from './ens-registry.json';
import ethRegistrarControllerABI from './ethRegistrarControllerABI.json';

const App = () => {
  const [walletAddress, setWalletAddress] = useState('');
  const [provider, setProvider] = useState(null);
  const [ensName, setENSName] = useState('');
  const [network, setNetwork] = useState('');
  const [balance, setBalance] = useState('');
  const [networkId, setNetworkId] = useState('');
  const [search , setSearch] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [message, setMessage] = useState('');
  const [disableCommit, setdisableCommit] = useState(false);
  // const [disableRegister, setdisableRegister] = useState(false);
  const [showRegister, setshowRegister] = useState(false);
  const [showCommit, setshowCommit] = useState(true);
  const connectWallet = async () => {
    try {
      // Requesting access to the user's MetaMask wallet
      await window.ethereum.request({ method: 'eth_requestAccounts' });
    } catch (error) {
      console.error('Error connecting to wallet:', error);
    }
  };
  
  useEffect(() => {
    const fetchENSName = async () => {
      try {
        if (!window.ethereum)return;

        // Connect to Ethereum network
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        setProvider(provider);
        const network = await provider.getNetwork();
        const networkId = network.chainId;

        // Fetch connected wallet address
        const accounts = await provider.listAccounts();
        if (!accounts[0]) return;
        setNetworkId(networkId);
        
        setWalletAddress(accounts[0]);
        setIsConnected(true);
          console.log(walletAddress);
      
        // contracts
         const address=walletAddress;
         const reverseName = `${address.slice(2)}.addr.reverse`;
         // Get the namehash of the reverse ENS name
         const node = ethers.utils.namehash(reverseName);
         // Get the resolver address for the reverse ENS name
         const resolverContract_ = new ethers.Contract('0xBde345E46BD6E069c59A1Af6730854e54A9B60e6', PublicResolverABI, provider);
                
          // Get the ENS name associated with the address
          const ensName_ = await resolverContract_.name(node);

          console.log("ENS name:",ensName_);
          setENSName(ensName_);

            // List of possible TLDs

          /*@@@@@@@@@@@@@@@@ optional not working@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/

        const tlds = ['eth', 'xyz', 'test','edx']; // replace with the list of TLDs you want to check
        const ensContract = new ethers.Contract('0x4A1D7178004BdC57c9BB70D608ff3b4d7f43E85e', ensRegistry.abi, provider);
        // Check each TLD
        for (let tld of tlds) {
            const fullName = `${ensName_}.${tld}`;
            const owner = await ensContract.owner(ethers.utils.namehash(fullName));
            if (owner.toLowerCase() === address.toLowerCase()) {
                console.log("full name:",fullName);
                return;
            }
          }

        // Fetch wallet balance
        const balance = await provider.getBalance(accounts[0]);
        setBalance(ethers.utils.formatEther(balance));
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    
    };

    fetchENSName();
  },[walletAddress]);



  const fetchAddress = async (search) => {
    try {

      const node = ethers.utils.namehash(search)
      node.replace(/^\./, '').toLowerCase();
      const resolverContract = new ethers.Contract('0xBde345E46BD6E069c59A1Af6730854e54A9B60e6',PublicResolverABI, provider); 
      const owner = await resolverContract['addr(bytes32)'](node);
      console.log("Domain Owner:", owner);
      if(owner==='0x0000000000000000000000000000000000000000'){
        setMessage(search+' is  available');
      }else{
        setMessage(search+ ' is already registered by'+'\n' +owner);
      }
      
    } catch (error) {
      console.error('Error :', error);
    }
  }

const commit = async (search) => {
 console.log("node:",ethers.utils.namehash(search));
  if(!testinput(search)) return;
  fetchAddress(search);
  
  const signer = provider.getSigner();
  const ethReg=new ethers.Contract('0xB9e5B587276fb7d07d5c0D9E356221ea71a6EC1b',ethRegistrarControllerABI.abi,signer);
  let price = await ethReg.rentPrice(search,31536000);
  const part=(price.toString()).split(",");
  price=part[0];

  const tx= await ethReg.makeCommitment(search,walletAddress,31536000,ethers.utils.formatBytes32String(''),'0xBde345E46BD6E069c59A1Af6730854e54A9B60e6',[],true,0);
  console.log("commitment:",tx);

  const tx2= await ethReg.commit(tx);
  setdisableCommit(true);
  await tx2.wait();
  console.log("commit:",tx2);
  setMessage('Commitment Successful wait 60 seconds for registration')
  
  setTimeout(() => {
    setshowRegister(true);
    setshowCommit(false);
    setMessage('');
  }, 61000);

}

const testinput = (e) => {
  const regex = /^[a-zA-Z0-9-]{4,}$/;
  if (!regex.test(e) || e.startsWith('.') || e.endsWith('.')) {
      setMessage('Please enter a valid domain (min 4 characters) that does not start or end with a dot (.)');
      return false;
  } else {
      setMessage('');
      return true;
  }
}

 const register = async () => {
  
  const node=ethers.utils.namehash(search);
  
  console.log("walletAddress:",walletAddress)
  console.log("node:",node)
  console.log("search:",search)

  const signer = provider.getSigner();
  const ethReg=new ethers.Contract('0xB9e5B587276fb7d07d5c0D9E356221ea71a6EC1b',ethRegistrarControllerABI.abi,signer);
  const resolver=new ethers.Contract('0xBde345E46BD6E069c59A1Af6730854e54A9B60e6',PublicResolverABI,signer);
  let price = await ethReg.rentPrice(search,31536000);
  const part=(price.toString()).split(",");
  price=part[0];
 

  const tx3= await ethReg.register(search,walletAddress,31536000,ethers.utils.formatBytes32String(''),'0xBde345E46BD6E069c59A1Af6730854e54A9B60e6',[],true,0,{value:price});
  await tx3.wait();
  
  // /const converted = ethers.utils.formatBytes32String('');
  const tx4= await resolver['setAddr(bytes32,address)'](node,walletAddress);
  await tx4.wait();

}

  useEffect(() => {
  if(isConnected){
    setNetworkId(networkId);
    if(networkId===1){
      setNetwork('Ethereum');
    }else if(networkId===1995){
      setNetwork('EDEXA testnet');
    }else if(networkId===5){
      setNetwork('Goerli');
    }else if(networkId===17000){
      setNetwork('Holesky testnet');
    }else if(networkId===11155111){
      setNetwork('Sepolia');}}else
      {setBalance('');
      setENSName('');
      setNetwork('');
      setNetworkId('');}
    
  
  },[isConnected])
  

  return (
    <div className="container" >
    {isConnected ? (
        <button className="button.connected" disabled={true} >
          Connected
        </button>
      ) : (
        <button className="button" onClick={connectWallet}>
          Connect Wallet
        </button>
      )}


    
    <div className="info">
      <p>Wallet Address: {walletAddress}</p>
      <p>ENS Name: {ensName}</p>
      <p>Network: {network}</p>
      <p>Network ID: {networkId}</p>
      <p>Balance: {balance} ETH</p>
    </div>
    <div className="input-container">
      <input style={{width: 'calc(50% - 100px)',marginRight: '20px'}} type="text" onChange={(e) => setSearch(e.target.value)} placeholder="Enter domain name" /><h2>.eth</h2>
      {showCommit && <button className="button" disabled={disableCommit} style={{cursor: disableCommit ? 'not-allowed' : 'pointer', opacity: disableCommit ? 0.5 : 1}} onClick={() => commit(search)}>commit your domain</button>}
      {showRegister && <button className='button'  onClick={()=>register()}>Register</button>}
    </div>
    <h3>{message}</h3>
  </div>
  );
};

export default App;
